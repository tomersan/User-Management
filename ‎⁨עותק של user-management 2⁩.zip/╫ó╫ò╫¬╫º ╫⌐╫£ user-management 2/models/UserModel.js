const mongoose = require("mongoose")


const nameSchema = mongoose.Schema({

    title:{
        type : String , 
        require : true
    } , 
    first : {
        type : String , 
        require : true
    } ,
    last : {
        type:String , 
        require : true

    }

},{
    timesStamps : true
})

const coordinatesSchema = mongoose.Schema({

    latitude:{
        type : String , 
        require : true
    }   , 
    longitude:{
        type : String , 
        require : true
    }  

})


const timezoneSchema = mongoose.Schema({

    offset:{
        type : String , 
        require : true
    }   , 
    description:{
        type : String , 
        require : true
    }  


})


const locationSchema = mongoose.Schema({

    street:{
        type : String , 
        require : true
    } , 
    city : {
        type : String , 
        require : true
    } ,
    state : {
        type:String , 
        require : true

    } , 
    country : {
        type:String , 
        require : true

    } , 
    postcode : {
        type:Number , 
        require : true
    },
    coordinates :[coordinatesSchema]
    , 
    timezone : [timezoneSchema]
    


},{
    timesStamps : true
})


const registeredSchema = mongoose.Schema({

    date:{
        type : Date , 
        require : true
    }   , 
    age:{
        type : Number , 
        require : true
    }  


})

const pictureSchema = mongoose.Schema({

    large:{
        type : String , 
        require : true
    }   , 
    medium:{
        type : String , 
        require : true
    } , 
    thumbnail:{
        type : String , 
        require : true
    }  



})


const userSchema = mongoose.Schema({

    
    name : [nameSchema] , 
    location : [locationSchema] , 
    email: {
        type: String,
        require: true
    },
    registered : [registeredSchema] , 
    picture : [pictureSchema] , 



},{
    timesStamps : true
})

const User = mongoose.model('users' , userSchema)

module.exports = User