const express = require('express')
const router = express.Router();
const User = require('../models/userModel')

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://tomer:0525770223,unrxb@cluster0.o2suh.mongodb.net/usermanagmnt3";


router.get("/getallusers", (req, res) => {


    User.find({}, (err, docs) => {

        if (!err) {
            return res.json({ data: docs })
        }
        else {
            return res.status(400).json({ messege: 'Somthing went wrong' })
        }
    })

});

router.get("/getuserbyname/:name", (req, res) => {


    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("usermanagmnt3");
        dbo.collection("users").find({ "name.first": { $regex: "Co", $options: req.params.name } }).toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            res.send(result)
            db.close();
        });
    });



    // User.find({"$text": {"name": req.params.name}} , (err , docs)=>{
    //     if(!err)
    //     {
    //         console.log(docs)
    //         res.send(docs)
    //     }
    //     else
    //     {
    //         return res.status(400).json({messege : 'Somthing went wrong'})
    //     }
    // })
})

router.post("/adduser", (req, res) => {

    let body = req.body

    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("usermanagmnt3");
        var myobj = body;
        dbo.collection("users").insertOne(myobj, function (err, result) {
            if (err) throw err;
            console.log("1 document inserted");
            res.send(result)
        });
    });

})

router.put("/modifyuser/:name", (req, res) => {

    let body = req.body
    let name = req.params.name

    console.log(body)

    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("usermanagmnt3");
        var myquery = { "name.first":name};
        var myobj = {$set : body};
        dbo.collection("users").updateOne(myquery ,  myobj, function (err, result) {
            if (err) throw err;
            console.log("1 document updated");
            res.send(result)
        });
    });

})

router.delete("/deleteuser/:name", (req, res) => {

    let name = req.params.name

    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("usermanagmnt3");
        var myquery = { "name.first":name};
        dbo.collection("users").deleteOne(myquery, function (err, result) {
            if (err) throw err;
            console.log("1 document deleted");
            res.send(result)
        });
    });

})







module.exports = router