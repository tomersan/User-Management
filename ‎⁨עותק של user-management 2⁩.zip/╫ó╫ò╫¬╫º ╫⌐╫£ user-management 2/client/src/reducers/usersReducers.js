export const getAllUsersReducer = (state = { users: [] }, action) => {

    switch (action.type) {
        case 'GET_USERS_REQUEST': return {
            loading: true
        }
        case 'GET_USERS_SUCCESS': return {
            users: action.payload,
            loading: false
        }
        case 'GET_USERS_FAILD': return {
            error: action.payload,
            loading: false
        }

        default: return state
    }

}

export const getUserByIdReducer = (state = { user: [] }, action) => {

    switch (action.type) {
        case 'GET_USERBYID_REQUEST': return {
            loading: true
        }
        case 'GET_USERBYID_SUCCESS': return {
            user: action.payload,
            loading: false
        }
        case 'GET_USERBYID_FAILD': return {
            error: action.payload,
            loading: false
        }

        default: return state
    }

}






