import axios from 'axios'
export const getAllUsers = () => dispatch => {

    dispatch({ type: 'GET_USERS_REQUEST' })

    axios.get('/api/users/getallusers').then(res => {
        console.log(res.data.data)
        dispatch({ type: 'GET_USERS_SUCCESS', payload: res.data.data})
    }).catch(err => {
        console.log(err);
        dispatch({ type: 'GET_USERS_FAILD', payload: err })
    })

}

export const getUserById = (userid) => dispatch => {

    dispatch({ type: 'GET_USERBYID_REQUEST' })

    axios.post('/api/users/getusersbyid', { userid }).then(res => {
        console.log(res.data)
        dispatch({ type: 'GET_USERBYID_SUCCESS', payload: res.data })
    }).catch(err => {
        console.log(err);
        dispatch({ type: 'GET_USERBYID_SUCCESS', payload: err })
    })




}






