import React from 'react'
import User from '../components/User'
import { useDispatch, useSelector } from 'react-redux'
import { useEffect, useState } from 'react'
import { getAllUsers } from '../actions/userAction'
import Modal from '../components/Modal'


export default function Homescreen() {

    const getAllUsersstate = useSelector(state => state.getAllUsersReducer)

    const { loading, users, error } = getAllUsersstate
    const dispatch = useDispatch()



    useEffect(() => {
        dispatch(getAllUsers())


    }, [])

    const [searchbar, setSearchbar] = useState("")
    const [AllUsers, setAllUsers] = useState(users)

    const [page, setPage] = useState(1)

    const [openModal, setOpenModal] = useState(false)


    let userinPage = 1
    let totalInPage = 10
    let count = -1

    useEffect(() => {
        if (page < 1) {
            setPage(1)
        }
        if (page > userinPage) {
            setPage(userinPage)
        }
    }, [page])

    const SearchBar = () => {

        if (searchbar === '') {
            setAllUsers(users)
            return
        }

        let newusers = []
        for (let i = 0; i < users.length; i++) {

            if (users[i].name[0].first.toString().toUpperCase().includes(searchbar.toString().toUpperCase()) || users[i].name[0].last.toString().toUpperCase().includes(searchbar.toString().toUpperCase()) || users[i].email.toString().toUpperCase().includes(searchbar.toString().toUpperCase()) || users[i].location[0].city.toString().toUpperCase().includes(searchbar.toString().toUpperCase()) || users[i].location[0].country.toString().toUpperCase().includes(searchbar.toString().toUpperCase())) {
                newusers.push(users[i])
            }

        }
        setAllUsers(newusers)
        setPage(page - 1)

    }
    useEffect(() => {

        setAllUsers(users)
        console.log(AllUsers)


    }, [loading === false])

    const ModalOpenFunc = () => {
        if (openModal === false) {
            setOpenModal(true)
        }
        else {
            setOpenModal(false)

        }
    }





    return (

        <div >
            <div className='row justify-content-center m-5'>
                <Modal open={openModal} func={ModalOpenFunc}></Modal>

                <input className='searchinput m-4' type="text" placeholder="search..." value={searchbar} onChange={(e) => { setSearchbar(e.target.value) }} />
                <button className='searchbtn m-4' onClick={(e) => { SearchBar() }}>Search</button>
                <button className='btnadduser m-4' onClick={(e) => ModalOpenFunc()}>+ New User</button>
            </div>
            <div className="row justify-content-center">
                <table>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Registered</th>

                    </tr>


                    {loading ? (<h1>Loading...</h1>) : error ? (<h1>Something went wrong</h1>) : (
                        AllUsers.map(users => {
                            count += 1
                            if (count === totalInPage) {
                                userinPage += 1
                                count = 0
                            }
                            return <tr>
                                <User users={users} page={page} userinPage={userinPage} totalInPage={totalInPage} />

                            </tr>
                        })
                    )}

                </table>


                <div className='pages m-5'>
                    <h1>{page} / {userinPage}</h1>
                    <button className='btn-back' onClick={(e) => setPage(page - 1)} >Back Page </button>
                    <button className='btn-next' onClick={(e) => setPage(page + 1)} >Next Page </button>

                </div>
            </div>

        </div>


    )
}
