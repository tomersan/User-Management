import React from 'react'
import { useState } from 'react'
import axios from 'axios'



export default function Modal(props) {

    const [title, settitle] = useState()
    const [first, setfirst] = useState()
    const [last, setlast] = useState()
    const [email, setemail] = useState()
    const [city, setcity] = useState()
    const [country, setcountry] = useState()
    const [pictureurl, setpictureurl] = useState()
    const [loading, setloading] = useState(false)


    const d = new Date()


    const Adduser = async (e) => {
        e.preventDefault()
        setloading(true)
        try {
            let user = {
                "name": {
                    "title": title,
                    "first": first,
                    "last": last
                },
                "location": {
                    "street": {
                        "number": "",
                        "name": ""
                    },
                    "city": city,
                    "state": "",
                    "country": country,
                    "postcode": "",
                    "coordinates": {
                        "latitude": "",
                        "longitude": ""
                    },
                    "timezone": {
                        "offset": "",
                        "description": ""
                    }
                },
                "email": email,
                "registered": {
                    "date": "2004-11-24T19:08:30.732Z",
                    "age": ""
                },
                "picture": {
                    "large": pictureurl,
                    "medium": pictureurl,
                    "thumbnail": pictureurl
                }
            }
            let res = await fetch('/api/users/adduser', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(user)

            })
            let data = await res.json()

            alert("User Added!")
            setloading(false)
            window.location.reload(true)

        }
        catch (err) { console.log(err) }
        setloading(false)


    }


    if (props.open === true) {


        return (

            <>
                <div className='bg-black1'></div>
                <div className='modal-user'>
                    <div className="header-modal">
                        <h1 className='title-modal m-4'>New User</h1>
                        <button className='btn-close' onClick={(e) => props.func(props.open)}></button>
                    </div>
                    <div className="content-modal">
                        <form className='adduserform' onSubmit={(e) => Adduser(e)}>

                            <input placeholder='Title' className='input-row' type="text" value={title} onChange={(e) => settitle(e.target.value)} />
                            <input placeholder='First Name' className='input-row' type="text" value={first} onChange={(e) => setfirst(e.target.value)} />
                            <input placeholder='Last Name' className='input-row' type="text" value={last} onChange={(e) => setlast(e.target.value)} />
                            <input placeholder='Email' className='input-row' type="email" value={email} onChange={(e) => setemail(e.target.value)} />
                            <input placeholder='City' className='input-row' type="text" value={city} onChange={(e) => setcity(e.target.value)} />
                            <input placeholder='Country' className='input-row' type="text" value={country} onChange={(e) => setcountry(e.target.value)} />
                            <input placeholder='Picture Url' className='input-row' type="text" value={pictureurl} onChange={(e) => setpictureurl(e.target.value)} />

                            {loading ? 'Loading...' : <button className='btn-op' type='submit'>Submit</button>}

                        </form>
                    </div>
                </div>

            </>

        )
    }
    else {
        return ""
    }

}

