import React from 'react'
import { Link } from 'react-router-dom'
import ModalModify from '../components/ModalModify'
import ModalDelete from '../components/ModalDelete'

import { useState } from 'react'


export default function User(props) {

    const [openModifyModal, setOpenModifyModal] = useState(false)
    const [openDeleteModal, setOpenDeleteModal] = useState(false)


    const ModalModifyOpenFunc = () => {
        if (openModifyModal === false) {
            setOpenModifyModal(true)
        }
        else {
            setOpenModifyModal(false)

        }
    }

    const ModalDeleteOpenFunc = () => {
        if (openDeleteModal === false) {
            setOpenDeleteModal(true)
        }
        else {
            setOpenDeleteModal(false)

        }
    }


    const DeleteUser = () => {

        ModalDeleteOpenFunc()


    }

    if (props.page === props.userinPage) {
        return (
            <>
                <ModalModify open={openModifyModal} func={ModalModifyOpenFunc} users={props.users}></ModalModify>
                <ModalDelete open={openDeleteModal} func={ModalDeleteOpenFunc} users={props.users}></ModalDelete>
                <td>
                    <img className='image-user' src={props.users.picture[0].thumbnail}></img>
                </td>
                <td>
                    <h6 >{props.users.name[0].first + " " + props.users.name[0].last}</h6>
                </td>
                <td>
                    <h6>{props.users["email"]}</h6>
                </td>
                <td>
                    <h6>{props.users.location[0].city + "," + props.users.location[0].country}</h6>
                </td>
                <td>
                    <h6>{props.users.registered[0].date}</h6>
                </td>
                <td>
                    <button className='btn-op' onClick={(e) => { ModalModifyOpenFunc() }}>Modify</button>
                </td>
                <td>
                    <button className='btn-op' onClick={(e) => { DeleteUser() }}>Delete</button>
                </td>

            </>

        )

    }
    else {
        return ""
    }
}
