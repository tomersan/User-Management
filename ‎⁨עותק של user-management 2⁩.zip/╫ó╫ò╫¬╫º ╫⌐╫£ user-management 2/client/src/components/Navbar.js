import React from 'react'

export default function () {
    return (
        <div>
            <nav className='nav-bar p-4'>
                <h3 className='logo'>MyApp</h3>
                <h3 className='logo2'>| User Management</h3>
            </nav>
            
        </div>
    )
}
