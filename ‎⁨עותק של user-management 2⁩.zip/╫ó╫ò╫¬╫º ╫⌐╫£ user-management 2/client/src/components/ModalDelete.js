import React from 'react'
import { Link } from 'react-router-dom'
import { useState } from 'react'


export default function ModalDelete(props) {

    const [loading, setloading] = useState(false)


    const Deleteuser = async () => {
        setloading(true)
        try {
            let res = await fetch('/api/users/deleteuser/' + props.users.name[0].first, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },

            })
            let data = await res.json()

            alert("User Deleted!")
            setloading(false)
            window.location.reload(true)

        }
        catch (err) { console.log(err) }
        setloading(false)
    }


    if (props.open === true) {


        return (

            <>
                <div className='bg-black1'></div>
                <div className='modal-user-modify'>
                    <div className="header-modal">
                        <h1 className='m-4'>Are You Sure you want to delete this user?</h1>
                        <button className='btn-close' onClick={(e) => props.func(props.open)}></button>
                        {loading ? 'Loading...' : <button className='btn-op m-4' onClick={(e) => Deleteuser()}>yes</button>}
                        <button className='btn-op m-4' onClick={(e) => props.func(props.open)}>No</button>
                    </div>

                </div>

            </>

        )
    }
    else {
        return ""
    }

}

