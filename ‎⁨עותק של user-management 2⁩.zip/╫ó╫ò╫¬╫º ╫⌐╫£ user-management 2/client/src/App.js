import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Route, Switch} from 'react-router-dom'
import bootstrap from '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Navbar from './components/Navbar';

import Homescreen from '../src/screens/Homescreen';


function App() {
  return (
    <div className="App">
      <Navbar/>

      <BrowserRouter>
      <Switch>
      <Route path='/' component={Homescreen} exact/>

      </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
