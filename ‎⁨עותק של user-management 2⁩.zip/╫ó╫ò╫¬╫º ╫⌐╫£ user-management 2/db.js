const mongoose = require("mongoose");

var mongoDBURL = 'mongodb+srv://tomer:0525770223,unrxb@cluster0.o2suh.mongodb.net/usermanagmnt3'

mongoose.connect(mongoDBURL , {useUnifiedTopology : true , useNewUrlParser:true })

var dbconnect = mongoose.connection

dbconnect.on(`error` , () =>{
    console.log('Mongo DB Connection Faild');
})

dbconnect.on('connected' , () =>{
    console.log(`Mongo DB Connection Successfull`)
})

module.exports = mongoose