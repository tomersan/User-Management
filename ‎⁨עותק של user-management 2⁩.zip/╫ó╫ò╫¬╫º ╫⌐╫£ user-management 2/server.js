const express = require("express")
const bodyParser = require("body-parser");
const app = express()

var dbconnection = require('./db')

var usersRoute = require('./routes/usersRoute')

app.use(bodyParser.json());

app.use(`/api/users/` , usersRoute)

app.get("/" , (req , res) => {

    res.send('This From Backend')

});


const port = 8001;

app.listen(port , () => console.log(`Node js Server Started`))